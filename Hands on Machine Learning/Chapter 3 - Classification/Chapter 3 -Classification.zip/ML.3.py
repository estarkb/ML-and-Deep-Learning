import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

train_set = pd.read_csv("C:\Users\estar\Desktop\ML.3\mnist_train.csv")
test_set = pd.read_csv("C:\Users\estar\Desktop\ML.3\mnist_test.csv")

X_train, y_train = train_set.iloc[:,1:], train_set.iloc[:,0]
X_test, y_test = test_set.iloc[:,1:], test_set.iloc[:,0]

Xtr = X_train.values
digit = Xtr[20000]
digit_image = digit.reshape(28, 28)
plt.imshow(digit_image, cmap=mpl.cm.binary, interpolation="nearest")
plt.axis("off")
plt.show()

def plot_digits(instances, images_per_row=10, **options):
    size = 28
    images_per_row = min(len(instances), images_per_row)
    images = [instance.reshape(size,size) for instance in instances]
    n_rows = (len(instances) - 1) // images_per_row + 1
    row_images = []
    n_empty = n_rows * images_per_row - len(instances)
    images.append(np.zeros((size, size * n_empty)))
    for row in range(n_rows):
        rimages = images[row * images_per_row : (row + 1) * images_per_row]
        row_images.append(np.concatenate(rimages, axis=1))
    image = np.concatenate(row_images, axis=0)
    plt.imshow(image, cmap = mpl.cm.binary, **options)
    plt.axis("off")

a=X_train.iloc[0:100,:].values
plot_digits(a, images_per_row=10)

"""CLASIFICADOR BINARIO"""
y_train_5 = (y_train==5)
y_test_5 = (y_test==5)

from sklearn.linear_model import SGDClassifier
sgd_clf = SGDClassifier()
sgd_clf.fit(X_train, y_train_5)
y_pred_5 = sgd_clf.predict(X_test)

"""CrossValidación"""
from sklearn.model_selection import cross_val_score
cross_val_score(sgd_clf, X_train, y_train_5, cv=3, scoring="accuracy")

"""Performance"""
from sklearn.metrics import recall_score, precision_score, confusion_matrix, f1_score #importo metricas
precision = precision_score(y_test_5, y_pred_5) #
recall = recall_score(y_test_5, y_pred_5)
f1 = f1_score(y_test_5, y_pred_5)
conf_matrix = pd.DataFrame(confusion_matrix(y_test_5, y_pred_5), columns = ["No Acertara", "Acertara"], index = ["No Acierta", "Acierta"])
conf_matrix["Total"] = conf_matrix["No Acertara"] + conf_matrix["Acertara"]
row = pd.DataFrame((conf_matrix.iloc[0,:] + conf_matrix.iloc[1,:]), columns=["Total"])
conf_matrix = conf_matrix.append(row.transpose())
#podemos ver que es recontramalo nuestro clasificador
#predice que todo no es un 5, así que está fácil tener un buen accuracy
#tal como ocure en la crosvalidación

"""MUY IMPORTANTE"""
"""Precision/Recall Tradeoff"""
plt.plot(recall, precision, "b-", linewidth=2)
plt.title("Tradeoff")
plt.xlabel("Recall")
plt.ylabel("Precision")

from sklearn.model_selection import cross_val_predict
y_scores = cross_val_predict(sgd_clf, X_train, y_train_5, cv=3, method="decision_function")
y_train_threshold = (y_scores>-100)
precision_score(y_train_5, y_train_threshold)

thresholds=10
from sklearn.metrics import precision_recall_curve
precision, recall, thresholds = precision_recall_curve(y_train_5, y_scores)
def plot_precision_recall_curve(precision, recall, thresholds):
    plt.plot(thresholds, precision[:-1], "b--", label="Precision")
    plt.plot(thresholds, recall[:-1], "g-", label="Precision")
    plt.xlabel("thresholds")
    plt.legend(loc="center_left")
    plt.show()
plot_precision_recall_curve(precision, recall, thresholds)



